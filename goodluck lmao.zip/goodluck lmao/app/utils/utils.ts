import {JWTPayload, jwtVerify, SignJWT} from "jose";
import dotenv from "dotenv";

dotenv.config();

if (!process.env.NEXT_PUBLIC_JWT_SECRET_KEY) {
  throw new Error(
    "NEXT_PUBLIC_JWT_SECRET_KEY must be defined in environment variables"
  );
}
const secretKey = process.env.NEXT_PUBLIC_JWT_SECRET_KEY;
if (secretKey.length === 0) {
  throw new Error("JWT secret key cannot be empty");
}
const key = new TextEncoder().encode(secretKey);

export async function encrypt(payload: JWTPayload) {
  return await new SignJWT(payload)
    .setProtectedHeader({alg: "HS256"})
    .setIssuedAt()
    .setExpirationTime("1h")
    .sign(key);
}

export async function decrypt(input: string): Promise<JWTPayload | null> {
  try {
    const {payload} = await jwtVerify(input, key, {
      algorithms: ["HS256"],
    });
    return payload;
  } catch (err) {
    console.error("JWT verification failed:", err);
    return null;
  }
}
