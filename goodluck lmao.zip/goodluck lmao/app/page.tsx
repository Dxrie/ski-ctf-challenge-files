"use client";

import {useEffect, useState} from "react";
import Link from "next/link";
import {useRouter} from "next/navigation";
import {decrypt} from "./utils/utils";

export default function Home() {
  const [username, setUsername] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    async function checkCookie() {
      // Check if user is authenticated
      const cookies = document.cookie.split(";");
      const authCookie = cookies.find((cookie) =>
        cookie.trim().startsWith("auth=")
      );

      if (!authCookie) {
        router.push("/register");
        return;
      }

      // Verify and decode JWT using decrypt function
      try {
        const token = authCookie.split("=")[1];
        const payload = await decrypt(token);

        if (!payload) {
          throw new Error("Invalid token");
        }

        setUsername(
          (payload.isAdmin as boolean)
            ? (process.env.NEXT_PUBLIC_FLAG as string)
            : (payload.username as string)
        );
      } catch (err) {
        console.error("Error verifying JWT:", err);
        document.cookie =
          "auth=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
        router.push("/register");
      }
    }

    checkCookie();
  }, [router]);

  const handleLogout = () => {
    document.cookie = "auth=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
    router.push("/register");
  };

  if (!username) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md p-8 space-y-6 bg-white dark:bg-[#1a1a1a] rounded-lg shadow-lg">
        <h1 className="text-2xl font-bold text-center">Welcome, {username}</h1>
        <div className="flex flex-col gap-4">
          <p className="text-center text-gray-600 dark:text-gray-400">
            You are successfully logged in.
          </p>
          <button
            onClick={handleLogout}
            className="w-full rounded-full bg-foreground text-background py-2 px-4 hover:bg-[#383838] dark:hover:bg-[#ccc] transition-colors"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
