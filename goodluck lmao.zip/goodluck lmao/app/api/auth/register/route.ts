import {encrypt} from "@/app/utils/utils";
import {NextRequest, NextResponse} from "next/server";

export async function POST(request: NextRequest) {
  try {
    const {username, password} = await request.json();

    if (!username || !password) {
      return Response.json(
        {
          status: "error",
          message: "Missing username or password",
        },
        {
          status: 400,
        }
      );
    }

    const jwtToken = await encrypt({username, password, isAdmin: false});

    return NextResponse.json(jwtToken, {status: 201});
  } catch (err: any) {
    // console.error(err);
    if (err instanceof Error) {
      return Response.json(
        {
          status: "error",
          message: err.message,
        },
        {
          status: 500,
        }
      );
    }
  }
}
